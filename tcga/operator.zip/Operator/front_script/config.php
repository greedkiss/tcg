<?php
/**
 * Created by PhpStorm.
 * User: DELL
 * Date: 2018/5/8
 * Time: 10:54
 */
return array(
    'ROOT'=>str_replace('\\','/',dirname(__DIR__)).'/sample_stores',
    'FILE_PREFIX'=>'pm',
);